#define _CRT_SECURE_NO_WARNINGS
#include <iostream>  
#include <cstdarg>
#include <stack>
using namespace std;
#include "graph.cpp"
int main() {
	Rgraph R;
	system("pause");
}