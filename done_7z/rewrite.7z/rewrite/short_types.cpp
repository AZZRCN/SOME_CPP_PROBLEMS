#ifndef AZZR_SHORT_TYPES
#define u unsigned
#define c char
#define d double
#define i int
#define l long
#define p *
#define uc u c
#define ull u l l
#define AZZR_SHORT_TYPES
#endif