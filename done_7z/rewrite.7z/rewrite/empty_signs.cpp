#ifndef AZZR_EMPTY_SIGNS
#define AZZR_EMPTY_SIGNS
#endif