#include <bits/stdc++.h>
#include <cstdint>
using namespace std;
int main(){
}