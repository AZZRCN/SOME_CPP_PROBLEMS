#include <bits/stdc++.h>
using namespace std;

int t;
int main                                           (){
    // vector<int>v;
    // vector<int>::iterator XXX = v.begin                                           ()+1;
    // int XX = 0;
    // v.front                                           ()                      ;
    // v.back                                           ()                      ;
    // v.insert                                           (XXX,XX)                      ;
    // v.pop_back                                           ()                      ;
    // v.push_back                                           (XX)                      ;
    // v.begin                                           ()                                         ;
    // v.end                                           ()                                   ;
    // v.clear                                           ()                                   ;
    // v.empty                                           ()                                   ;
    // v.data                                           ()                                   ;
    // v.erase                                           (v.begin                                           ())                                   ;
    // v.size                                           ()                         ;
    // stack<int>s;
    // string str;
    // s  .pop                                               (                              );
    // s  .push                                                                  (XX);
    // s  .top                                               (                              );
    // s  .swap                                                                  (s);
    // str.c_str                                               (                              );
    // str.length                                               (                              );
    // str.npos;
    // str.compare                                                                  (str);
    // str.substr                                               (                              );
    // str.reserve                                               (                              );
    // str.find_first_not_of                                                 ('a');
    // str.find_first_of                                                 ('a');
    // str.find_last_not_of                                                 ('a');
    // str.find_last_of                                                 ('a');
    // list<int> l;
    // l.resize                                                     (100);
    // l.sort                                                     ();
    // l.remove_if                                                     (1);



    // 127                                                                 ;
    // 32767                                ;
    // 2147483647                        ;
    // 18446744073709551616                   ;
    // static_assert(0,"Are you sure this is C++?");
}
