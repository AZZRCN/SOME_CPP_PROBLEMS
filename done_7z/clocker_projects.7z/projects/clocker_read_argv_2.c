#include <stdio.h>
#include <synchapi.h>
int main(){
	unsigned long long second=0;
	scanf("%lld",&second);
	while(second--){
		Sleep(1000);
		
		printf("%d",second);
	}
}