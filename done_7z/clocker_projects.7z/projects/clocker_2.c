#include <stdio.h>
#include <synchapi.h>
char buf[128];
char*p = buf;
int second=0;
int multi=1;
int const arr[]={0,60,60,24,30};
const int* arr_cur = arr+1;
int read_charp_move(char**p){
	unsigned int n = 0;
	unsigned char ch = *((*p)++);
	while ((ch ^ '0') > 0x9) {ch = *((*p)++);}
	while ((ch ^ '0') < 0xA) {n = n * 0xA + ch - 0x30;ch = *((*p)++);}
    return ((*p)--,n);
}
int main(int argc,char** argv){
    if(argc >= 2){
        for(int i = 1; i < argc; i++){
			second += multi*read_charp_move(&argv[i]);
			multi*=arr[i];
		}
    }
	else{
		puts("请输入计时时间(以秒,分钟,小时,天)(换行即视为输入):");
		gets(buf);
		while(*p){
			second += multi*read_charp_move(&p);
			multi *= *(arr_cur++);
		}
	}
	while(second > 0){
		printf("%d",second);
		Sleep(1000);
		second--;
	}
	puts("END!");
}
/**
-fexec-charset=gbk -finput-charset=gbk
*/