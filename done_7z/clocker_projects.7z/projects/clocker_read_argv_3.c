#include <stdio.h>
#include <time.h>
int main(){
	unsigned long long second=0;
	struct timespec p;
	p.tv_sec=1;
	p.tv_nsec=0;
	scanf("%lld",&second);
	while(second--){
		nanosleep(&p,&p);
		printf("%d",second);
	}
}