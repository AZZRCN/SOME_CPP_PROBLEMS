#include <stdio.h>
#include <time.h>
// #include <windows.h>
//the Part of windows.h
#include <windef.h>
// #include <wincon.h>
#include <synchapi.h>
//end
#include <winuser.h>

int second=0;
int arr[]={0,60,60,24,30};
int read_charp(char*p){
	unsigned int n = 0;
	unsigned char ch = *(p++);
	while ((ch ^ '0') > 0x9) {ch = *(p++);}
	while ((ch ^ '0') < 0xA) {n = n * 0xA + ch - 0x30;ch = *(p++);}
    return n;
}
int read_charp_move(char**p){
	unsigned int n = 0;
	unsigned char ch = *((*p)++);
	while ((ch ^ '0') > 0x9) {ch = *((*p)++);}
	while ((ch ^ '0') < 0xA) {n = n * 0xA + ch - 0x30;ch = *((*p)++);}
    return ((*p)--,n);
}
// int read_stream(FILE* _Stream){
// 	unsigned int n = 0;
// 	unsigned char ch = fgetc(_Stream);
// 	while ((ch ^ '0') > 0x9) {ch = fgetc(_Stream);}
// 	while ((ch ^ '0') < 0xA) {n = n * 0xA + ch - 0x30;ch = fgetc(_Stream);}
//     return n;
// }
// _Bool peek(){
// 	int ans;
// 	ungetc(ans = getc(stdin),stdin);
// 	return ans;
// }
char* buf;
int main(int argc,char** argv){
	system("chcp 65001");
	int multi=1;
    if(argc >= 2){
        for(int i = 1; i < argc; i++){
			second += multi*read_charp(argv[i]);
			multi*=arr[i];
		}
    }
	else{
		puts("请输入计时时间(以秒,分钟,小时,天)(换行即视为输入):");
		buf = (char*)malloc(128);
		gets(buf);
		char*p = buf;
		int* i = arr+1;
		while(*p!='\0'){
			second += multi*read_charp_move(&p);
			multi *= *(i++);
		}
		p=NULL;i=NULL;
	}
	// printf("%d",second);
	while(second > 0){
		printf("%d",second);
		Sleep(1000);
		second--;
	}
	MessageBoxW(NULL,L"计时结束",L"无标题",0);
}
/**
-fexec-charset=gbk -finput-charset=gbk
*/