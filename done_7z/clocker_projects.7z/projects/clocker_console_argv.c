#include <stdio.h>
#include <time.h>
char buf[128];
char*p = buf;
unsigned long long second=0;
unsigned long long multi=1;
unsigned long long const arr[]={0,60,60,24,30};
const unsigned long long* arr_cur = arr+1;
int read_charp_move(char**p){
	unsigned int n = 0;
	unsigned char ch = *((*p)++);
	while ((ch ^ '0') > 0x9) {ch = *((*p)++);}
	while ((ch ^ '0') < 0xA) {n = n * 0xA + ch - 0x30;ch = *((*p)++);}
    return ((*p)--,n);
}

__forceinline void const nop_100(){
	for(int i = 1; i <= 100; i++)__asm__ __volatile__("nop");
}
int main(int argc,char** argv){
    if(argc >= 2){
        for(int i = 1; i < argc; i++){
			second += multi*read_charp_move(&argv[i]);
			multi*=arr[i];
		}
    }
	else{
		puts("请输入计时时间(以秒,分钟,小时,天)(换行即视为输入):");
		gets(buf);
		while(*p){
			second += multi*read_charp_move(&p);
			multi *= *(arr_cur++);
		}
	}
	const unsigned long long pivot = time(NULL);
	const unsigned long long end = time(NULL)+second;
	const unsigned long long time_length = second;
	second = 0;
	while(second < time_length){
		printf("%d",second);
		fail:
		nop_100();
		if(time(0)==pivot+second){
			goto fail;
		}
		else{
			second++;
		}
	}
	puts("END!");
}
/**
-fexec-charset=gbk -finput-charset=gbk
*/