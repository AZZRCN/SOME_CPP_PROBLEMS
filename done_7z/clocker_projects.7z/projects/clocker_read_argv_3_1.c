#include <stdio.h>
#include <unistd.h>
int main(){
	int s;
	__mingw_fscanf(stdin,"%d",(char*)&s);
	sleep(s);
}