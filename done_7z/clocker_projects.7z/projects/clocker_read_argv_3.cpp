#include <stdio.h>
#include <synchapi.h>
unsigned int s;
int main(){
	scanf("%d",&s);
	while(s--){
		Sleep(1000);
		printf("%d",s);
	}
}