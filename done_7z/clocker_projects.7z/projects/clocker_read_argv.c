#include <stdio.h>
// #include <time.h>
#include <synchapi.h>
unsigned long long second=0;
__forceinline bool const is_digit(const char c){
	return (c>='0')&&(c<='9');
}
const void input(){
	char buf[128];
	char*p = buf;
	unsigned long long t=0;
	const unsigned long long arr[]={1,60,3600,86400};
	gets(buf);
	int ar=0;
	for(;;){
		while(is_digit(*p)){
			t=t*10+(*(p++)-'0');
		}
		second += arr[ar]*t;
		if(*p=='\0')return;
		p++;
		t=0;
		ar++;
	}
}
int main(int argc,char** argv){
	puts("请输入计时时间(以秒,分钟,小时,天)(换行即视为输入):");
	input();
	// const unsigned long long pivot = time(NULL);
	// const unsigned long long time_length = second;
	// second = 0;
	// while(second < time_length){
	// 	printf("%d",second);
	// 	fail:
	// 	if(time(0)==pivot+second){
	// 		goto fail;
	// 	}
	// 	else{
	// 		second++;
	// 	}
	// }
	while(second--){
		Sleep(1000);
		printf("%d",second);
	}
	puts("END!");
}